﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeAffairsDigitalIdentityProcessor
{
    internal class ServiceRequest
    {
        public string RequestType { get; set; }
        public int PriorityLevel { get; set; }   // 1 - 5
        public int SeverityLevel { get; set; }   // 1 - 10
        public int EstimatedHours { get; set; }
        public Resident Resident { get; set; }

        // Constructor
        public ServiceRequest(string type, int priority, int severity, int hours, Resident resident)
        {
            RequestType = type;
            PriorityLevel = priority;
            SeverityLevel = severity;
            EstimatedHours = hours;
            Resident = resident;
        }

        // Calculate urgency score
        public int CalculateUrgency()
        {
            return PriorityLevel * SeverityLevel;
        }

        // Display request info
        public void DisplayRequest()
        {
            Console.WriteLine($"Request: {RequestType}");
            Console.WriteLine($"Priority: {PriorityLevel}");
            Console.WriteLine($"Severity: {SeverityLevel}");
            Console.WriteLine($"Estimated Hours: {EstimatedHours}");
            Console.WriteLine($"Urgency Score: {CalculateUrgency()}");
        }
    }
}
