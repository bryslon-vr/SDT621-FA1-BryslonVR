﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeAffairsDigitalIdentityProcessor
{
    internal class Resident
    {
        // This class stores information about a resident
        
        
            // Properties (auto-implemented)
            public string Name { get; set; }
            public string Address { get; set; }
            public string AccountNumber { get; set; }
            public double MonthlyUsage { get; set; }

            // Constructor to initialize the resident
            public Resident(string name, string address, string accountNumber, double usage)
            {
                Name = name;
                Address = address;
                AccountNumber = accountNumber;
                MonthlyUsage = usage;
            }

            // Method to display resident details
            public void DisplayResident()
            {
                Console.WriteLine($"Name: {Name}");
                Console.WriteLine($"Address: {Address}");
                Console.WriteLine($"Account No: {AccountNumber}");
                Console.WriteLine($"Monthly Usage: {MonthlyUsage}");
            }
        
    }
}
