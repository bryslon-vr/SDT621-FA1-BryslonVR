﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeAffairsDigitalIdentityProcessor
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Resident> residents = new List<Resident>();
            UtilitiesManager manager = new UtilitiesManager();

            try
            {
                // Step 1: Capture residents
                Console.Write("Enter number of residents: ");
                int residentCount = int.Parse(Console.ReadLine());

                for (int i = 0; i < residentCount; i++)
                {
                    Console.WriteLine($"\nResident {i + 1}");

                    Console.Write("Name: ");
                    string name = Console.ReadLine();

                    Console.Write("Address: ");
                    string address = Console.ReadLine();

                    Console.Write("Account Number: ");
                    string acc = Console.ReadLine();

                    // Validate numeric input
                    double usage;
                    while (!double.TryParse(Console.ReadLine(), out usage))
                    {
                        Console.Write("Invalid input. Enter numeric usage: ");
                    }

                    Resident r = new Resident(name, address, acc, usage);
                    residents.Add(r);
                }

                // Step 2: Capture requests
                Console.Write("\nEnter number of service requests: ");
                int requestCount = int.Parse(Console.ReadLine());

                for (int i = 0; i < requestCount; i++)
                {
                    Console.WriteLine($"\nRequest {i + 1}");

                    Console.Write("Select Resident Index (0-based): ");
                    int resIndex = int.Parse(Console.ReadLine());

                    Console.Write("Request Type: ");
                    string type = Console.ReadLine();

                    int priority;
                    while (!int.TryParse(Console.ReadLine(), out priority) || priority < 1 || priority > 5)
                    {
                        Console.Write("Enter priority (1-5): ");
                    }

                    int severity;
                    while (!int.TryParse(Console.ReadLine(), out severity) || severity < 1 || severity > 10)
                    {
                        Console.Write("Enter severity (1-10): ");
                    }

                    Console.Write("Estimated Hours: ");
                    int hours = int.Parse(Console.ReadLine());

                    ServiceRequest req = new ServiceRequest(type, priority, severity, hours, residents[resIndex]);
                    manager.AddRequest(req);
                }

                // Step 3: Display queue
                manager.DisplayQueue();

                // Step 4: Process requests
                while (manager.Requests.Count > 0)
                {
                    Console.Write("\nSelect request index to process: ");
                    int index = int.Parse(Console.ReadLine());

                    manager.ProcessRequest(index);
                    manager.DisplayQueue();
                }

                // Step 5: Summary display
                manager.ShowSummary();
            }
            catch (Exception ex)
            {
                // General error handling
                Console.WriteLine($"Error occurred: {ex.Message}");
            }

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}
