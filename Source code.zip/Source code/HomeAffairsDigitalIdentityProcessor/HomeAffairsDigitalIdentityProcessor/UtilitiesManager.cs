﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeAffairsDigitalIdentityProcessor
{
    internal class UtilitiesManager
    {
        public List<ServiceRequest> Requests = new List<ServiceRequest>();
        public List<ServiceRequest> CompletedRequests = new List<ServiceRequest>();

        // Add request to list
        public void AddRequest(ServiceRequest request)
        {
            Requests.Add(request);
        }

        // Display queue
        public void DisplayQueue()
        {
            Console.WriteLine("\n--- Pending Requests ---");

            foreach (var req in Requests)
            {
                Console.WriteLine($"{req.RequestType} | Urgency: {req.CalculateUrgency()}");
            }
        }

        // Process a request
        public void ProcessRequest(int index)
        {
            if (index >= 0 && index < Requests.Count)
            {
                var req = Requests[index];

                Console.WriteLine("\n--- Processing Request ---");
                req.Resident.DisplayResident();
                req.DisplayRequest();

                CompletedRequests.Add(req);
                Requests.RemoveAt(index);
            }
            else
            {
                Console.WriteLine("Invalid selection.");
            }
        }

        // Show summary
        public void ShowSummary()
        {
            Console.WriteLine("\n--- Summary ---");

            int highest = 0;
            ServiceRequest highestReq = null;

            foreach (var req in CompletedRequests)
            {
                Console.WriteLine($"{req.RequestType} - Urgency: {req.CalculateUrgency()}");

                if (req.CalculateUrgency() > highest)
                {
                    highest = req.CalculateUrgency();
                    highestReq = req;
                }
            }

            if (highestReq != null)
            {
                Console.WriteLine($"\nHighest Urgency Request: {highestReq.RequestType} ({highest})");
            }
        }
    }
}
