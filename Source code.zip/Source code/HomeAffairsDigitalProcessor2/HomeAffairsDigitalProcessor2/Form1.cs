﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HomeAffairsDigitalProcessor2
{
    public partial class Form1 : Form
    {
        private CitizenProfile currentProfile;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnValidate_Click(object sender, EventArgs e)
        {
            try
            {
                string name = txtName.Text.Trim();
                string id = txtID.Text.Trim();
                string citizenship = cmbCitizen.SelectedItem.ToString();

                // Check for empty input
                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(id))
                {
                    MessageBox.Show("Please fill in all fields.");
                    return;
                }

                // Create profile object
                currentProfile = new CitizenProfile(name, id, citizenship);

                // Display validation result and age in label
                lblStatus.Text = currentProfile.GetValidationMessage();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            try
            {
                if (currentProfile == null)
                {
                    MessageBox.Show("Please validate the ID first.");
                    return;
                }

                // Display full profile in multiline TextBox
                string output =
                    "----- PROFILE SUMMARY -----\r\n" +
                    $"Name: {currentProfile.FullName}\r\n" +
                    $"ID Number: {currentProfile.IDNumber}\r\n" +
                    $"Age: {currentProfile.Age}\r\n" +
                    $"Citizenship: {currentProfile.CitizenshipStatus}\r\n" +
                    $"Validation: {currentProfile.GetValidationMessage()}\r\n" +
                    $"Processed On: {DateTime.Now}";

                txtOutput.Text = output;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
