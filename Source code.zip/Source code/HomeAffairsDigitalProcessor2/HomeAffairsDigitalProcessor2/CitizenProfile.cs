﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeAffairsDigitalProcessor2
{
    internal class CitizenProfile
    {
        public string FullName { get; set; }
        public string IDNumber { get; set; }
        public int Age { get; set; }
        public string CitizenshipStatus { get; set; }

        public CitizenProfile(string name, string id, string citizenship)
        {
            FullName = name;
            IDNumber = id;
            CitizenshipStatus = citizenship;

            Age = CalculateAge();
        }

        private int CalculateAge()
        {
            try
            {
                string yearPart = IDNumber.Substring(0, 2);
                string monthPart = IDNumber.Substring(2, 2);
                string dayPart = IDNumber.Substring(4, 2);

                int year = int.Parse(yearPart);
                int month = int.Parse(monthPart);
                int day = int.Parse(dayPart);

                int fullYear;
                if (year <= DateTime.Now.Year % 100)
                    fullYear = 2000 + year;
                else
                    fullYear = 1900 + year;

                DateTime birthDate = new DateTime(fullYear, month, day);

                int age = DateTime.Now.Year - birthDate.Year;

                if (DateTime.Now < birthDate.AddYears(age))
                    age--;

                return age;
            }
            catch
            {
                return 0;
            }
        }

        public bool IsValidID()
        {
            if (IDNumber.Length != 13)
                return false;

            if (!long.TryParse(IDNumber, out _))
                return false;

            if (Age <= 0 || Age > 120)
                return false;

            return true;
        }

        // Returns message used by the label
        public string GetValidationMessage()
        {
            if (IsValidID())
                return $"ID Valid | Age: {Age}";
            else
                return "Invalid ID";
        }
    }
}
