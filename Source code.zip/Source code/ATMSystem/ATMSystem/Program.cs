﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATMSystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("—— CTU Simple ATM System ——\n");


                // Get user name
                Console.Write("HI , WHAT IS YOUR NAME?\n");
                string name = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(name))
                    throw new Exception("Name cannot be empty.");

                Console.WriteLine($"\nWELCOME {name.ToUpper()}!");

                // Get account balance
                decimal balance = GetValidAmount("Enter account balance: ");

                // Get withdrawal amount
                decimal withdrawal = GetValidAmount("Enter withdrawal amount: ");

                // Validate withdrawal
                if (withdrawal <= 0)
                    throw new Exception("Withdrawal amount must be greater than 0.");

                if (withdrawal > balance)
                    throw new Exception("Insufficient funds.");

                // Perform transaction
                decimal updatedBalance = balance - withdrawal;

                Console.WriteLine("\nWithdrawal successful!");

                // Format with comma decimal style
                var culture = (CultureInfo)CultureInfo.InvariantCulture.Clone();
                culture.NumberFormat.NumberDecimalSeparator = ",";
                culture.NumberFormat.NumberGroupSeparator = " ";

                Console.WriteLine($"Updated Balance: {updatedBalance.ToString("N2", culture)}");
                Console.WriteLine($"Transaction Time: {DateTime.Now:dd MMM yyyy HH:mm:ss}");

                Console.WriteLine("\nPress any key to exit...");
                Console.ReadKey();
            }
            catch (FormatException)
            {
                Console.WriteLine("Error: Please enter a valid numeric value.");
            }
            catch (OverflowException)
            {
                Console.WriteLine("Error: Number entered is too large.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }

        // Method for safe numeric input
        static decimal GetValidAmount(string prompt)
        {
            while (true)
            {
                try
                {
                    Console.Write(prompt);
                    string input = Console.ReadLine();

                    if (string.IsNullOrWhiteSpace(input))
                        throw new Exception("Input cannot be empty.");

                    decimal amount = decimal.Parse(input);

                    if (amount < 0)
                        throw new Exception("Amount cannot be negative.");

                    return amount;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input. Enter numbers only.");
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Number too large. Try again.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
        }
    }

