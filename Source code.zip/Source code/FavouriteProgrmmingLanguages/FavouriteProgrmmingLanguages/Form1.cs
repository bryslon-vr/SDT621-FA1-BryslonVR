﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FavouriteProgrmmingLanguages
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                // Get input from textbox
                string language = txtLanguage.Text.Trim();

                //  Check if empty
                if (string.IsNullOrEmpty(language))
                {
                    MessageBox.Show("Please enter a programming language.", "Input Error");
                    return;
                }

                // Check for duplicates
                foreach (var item in lstLanguages.Items)
                {
                    if (item.ToString().ToLower() == language.ToLower())
                    {
                        MessageBox.Show("This language already exists.", "Duplicate Error");
                        return;
                    }
                }

                //  Add language to list
                lstLanguages.Items.Add(language);

                //  Display date & time
                lblDateTime.Text = $"Added on: {DateTime.Now}";

                // Clear textbox
                txtLanguage.Clear();
            }
            catch (Exception ex)
            {
                // General error handling
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            try
            {
                //  Check if something is selected
                if (lstLanguages.SelectedItem == null)
                {
                    MessageBox.Show("Please select a language to remove.", "Selection Error");
                    return;
                }

                //  Remove selected item
                lstLanguages.Items.Remove(lstLanguages.SelectedItem);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
