﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Question_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Get student name
                Console.Write("Enter student name: ");
                string studentName = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(studentName))
                {
                    throw new Exception("Student name cannot be empty.");
                }

                // Get marks with validation
                int mark1 = GetValidMark("Enter mark for Subject 1: ");
                int mark2 = GetValidMark("Enter mark for Subject 2: ");
                int mark3 = GetValidMark("Enter mark for Subject 3: ");

                // Calculate total and average
                int total = checked(mark1 + mark2 + mark3); // catches overflow
                double average = total / 3.0;

                // Determine result
                string result = average >= 50 ? "PASS" : "FAIL";

                // Display results
                Console.WriteLine("\n===== STUDENT RESULTS =====");
                Console.WriteLine($"Student Name: {studentName}");
                Console.WriteLine($"Total Marks: {total}");
                Console.WriteLine($"Average Marks: {average:F1}");
                Console.WriteLine($"Result: {result}");
                Console.WriteLine($"Result Issued At: {DateTime.Now:dd MMM yyyy HH:mm:ss}");

                Console.WriteLine("\nPress any key to exit...");
                Console.ReadKey();
            }
            catch (OverflowException)
            {
                Console.WriteLine("Error: The numbers entered are too large.");
            }
            catch (FormatException)
            {
                Console.WriteLine("Error: Invalid number format.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error: {ex.Message}");
            }
        }

        static int GetValidMark(string prompt)
        {
            while (true)
            {
                try
                {
                    Console.Write(prompt);
                    string input = Console.ReadLine();

                    if (string.IsNullOrWhiteSpace(input))
                    {
                        throw new Exception("Input cannot be empty.");
                    }

                    int mark = int.Parse(input); // will throw if invalid

                    if (mark < 0 || mark > 100)
                    {
                        throw new Exception("Mark must be between 0 and 100.");
                    }

                    return mark;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Invalid input. Please enter a numeric value.");
                }
                catch (OverflowException)
                {
                    Console.WriteLine("Number is too large. Please enter a valid mark.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
}
